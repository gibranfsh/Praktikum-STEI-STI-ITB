#Nama : Gibran Fasha Ghazanfar
#NIM : 16521125

#TUGAS ke-2 : Program Menentukan Jumlah Kelulusan Mahasiswa
#SPESIFIKASI : Menentukan jumlah mahasiswa yang lulus dan tidak lulus
print("-----TUGAS ke-2 : Program Menentukan Jumlah Kelulusan Mahasiswa-----")

#KAMUS :
#s_lulus, s_gagal, i =  int
#indeks = array of string

#ALGORITMA :
indeks = [0 for i in range(50)] #Array dengan range/interval sepanjang 20 (0--49)
s_lulus = 0
s_gagal = 0

for i in range(50):
    indeks[i] = input("Masukan indeks ke-" + str(i) + " : ") #Mengisi array dari pengguna
    if indeks[i] == "A" or indeks[i] == "B" or indeks[i] == "C": #Indeks lulus
        s_lulus += 1 #Menambahkan jumlah siswa yang lulus
    
    elif indeks[i] == "D" or indeks[i] == "E": #Indeks tidak lulus
        s_gagal += 1 #Menambahkan jumlah siswa yang tidak lulus
    
    else:
        print("Masukanlah hanya indeks yang tersedia (A, B, C, D, atau E)")

print("Jumlah mahasiswa lulus :", s_lulus) #Mencetak jumlah mahasiswa yang lulus
print("Jumlah mahasiswa tidak lulus :", s_gagal) #Mencetak jumlah mahasiswa yang tidak lulus