#Nama : Gibran Fasha Ghazanfar
#NIM : 16521125

#TUGAS ke-4 : Program Mencari Indeks Terakhir
#SPESIFIKASI : Mencari indeks terakhir di mana X ditemukan di T
print("-----TUGAS ke-4 : Program Mencari Indeks Terakhir-----")

#KAMUS :
#N, X = int
#T = array of integer
#found = boolean

#ALGORITMA :
N = int(input("Masukan jumlah angka : ")) #Masukan jumlah array
X = int(input("Masukan angka yang ingin dicari! : ")) #Masukan angka dalam array yang ingin dicari indeksnya
T= [0 for i in range(0, N)] #Range T 0--N
found = False

for i in range(0, N):
    T[i] = int(input("Masukan nilai ke-" + str(i+1) + " : ")) #Mengisi array dari pengguna
    while i < N and found == False: #Kondisi ketika i lebih kecil daripada N
        if T[i] == X: #Ketika "T[i] = X" maka "found = 5 True", selain itu "i = i + 1"
            found = True
        else:
            i += 1

if found == True: #Ketika "found = True" akan dicetak sebuah ungkapan, selain "found = True" juga akan mencetak ungkapan lain
    print("Angka " + str(X) + " ditemukan di indeks ke-" + str(i+1))

else:
    print("Angka " + str(X) + " tidak ditemukan.")