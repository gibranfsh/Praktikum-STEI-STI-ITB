#Nama : Gibran Fasha Ghazanfar
#NIM : 16521125

#TUGAS ke-1 : Program yang Mengalikan Suatu Variabel terhadap Sebuah Array
#SPESIFIKASI : Mengalikan suatu variabel yang diberikan terhadap sebuah array
print("-----TUGAS ke-1 : Program yang Mengalikan Suatu Variabel terhadap Sebuah Array-----")

#KAMUS :
#i, X, Y = int
#T = array of integer

#ALGORITMA :
T = [0 for i in range(20)] #Array dengan range/interval sepanjang 20 (0--19)

for i in range(20):
    T[i] = int(input("Masukan angka ke-" + str(i) + " : ")) #Mengisi array dari pengguna

for i in range(20):
    print("Nilai angka ke-" + str(i) + "adalah " + str(T[i])) #Mencetak Array

X = int(input("Masukan angka untuk dikalikan dengan array : ")) #Mengisi variabel pengali

for i in range(20):
    Y = T[i] * X
    print("Nilai angka ke-" + str(i) + " setelah dikalikan : " + str(Y)) #Mencetak nilai array setelah dikalikan dengan variabel pengali

