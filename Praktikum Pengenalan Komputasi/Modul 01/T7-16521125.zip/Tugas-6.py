#Nama : Gibran Fasha Ghazanfar
#NIM : 16521125

#TUGAS ke-6 : Program Menentukan Hal yang Berkaitan dengan Suhu di Kota Bandung
#SPESIFIKASI : Menentukan rata-rata suhu, suhu terendah, tanggal ketika suhu >= 30 derajat celsius, tanggal pertama kali suhu < 15 derajat celcius
print("-----TUGAS ke-6 : Program Menentukan Hal yang Berkaitan dengan Suhu di Kota Bandung-----")

#KAMUS :
#N, X, count = int
#sum, Rata = float
#S = array of float
#found = boolean

#ALGORITMA :
N = 30
S = [0 for i in range(0, N)]
X = 15
sum = 0
count = 0
found = False
res = []

for i in range(0, N): 
    S[i] = float(input("Masukan suhu hari ke-" + str(i+1) + " : ")) #Masukan suhu dari hari ke-1 s.d. hari ke-30
    sum += S[i]
    count += 1
    min = S[0]
    if S[i] < min: #Jika indeks ke-i lebih kecil daripada indeks ke-0, indeks ke-i akan menggantikan indeks ke-0
        min = S[i]

    while i < N and found == False: #Kondisi ketika i lebih kecil daripada N
        if S[i] == X: #Ketika "S[i] = X" maka "found = True", selain itu "i = i + 1"
            found = True
        else:
            i += 1

for i in range(0, N):
    if S[i] >= 30: #Jika indeks ke-i lebih besar dari sama dengan indeks 30, i akan ditambahkan ke dalam list res[]
        res.append(i+1)
    
Rata = sum/count #Rata-rata suhu

print("Rata-rata suhu adalah " + str(Rata) + " celsius") #Mencetak rata-rata suhu

print("Suhu terendah adalah : " + str(min) + " celsius") #Mencetak suhu min terkecil

if found == True: #Ketika "found = True" akan dicetak sebuah ungkapan, selain "found = True" juga akan mencetak ungkapan lain
    print("Suhu 15 derajat celsius pertama kali terukur pada hari ke-" + str(i+1))

else:
    print("Suhu tidak pernah di bawah 15 derajat celsius") 

print("Suhu lebih dari sama dengan 30 derajat celsius terdapat pada hari : " + str(res)) #Mencetak hari apa saja ketika suhu lebih dari sama dengan 30 derajat celsius
