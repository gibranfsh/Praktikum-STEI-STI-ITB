#Nama : Gibran Fasha Ghazanfar
#NIM : 16521125

#TUGAS ke-5 : Program Penjumlahan Dua Buah Vektor
#SPESIFIKASI : Menjumlahkan dua buah vektor dan menghasilkan vektor baru
print("-----TUGAS ke-5 : Program Penjumlahan Dua Buah Vektor-----")

#KAMUS :
#N = int
#U, V , W = array of integer

#ALGORITMA :
N = int(input("Masukan jumlah elemen vektor! : ")) #Jumlah indeks array
U = [0 for i in range(0, N)] #Range U, 0--N
V = [0 for i in range(0, N)] #Range V, 0--N
W = [0 for i in range(0, N)] #Range W, 0--N

for i in range(0, N):
    U[i] = int(input("Masukan elemen vektor U ke-" + str(i+1) + " : ")) #Masukan elemen vektor U

for i in range(0, N):
    V[i] = int(input("Masukan elemen vektor V ke-" + str(i+1) + " : ")) #Masukan elemen vektor V

for i in range(0, N): #Menjumlahkan vektor U dengan vektor V menghasilkan vektor W
    W[i] = U[i] + V[i]

print("Elemen-elemen vektor U adalah : ") #Mencetak array vektor U
print(U)

print("Elemen-elemen vektor V adalah : ") #Mencetak array vektor V
print(V)

print("Sehingga elemen-elemen dari penjumlahan vektor U dan V adalah : ") #Mencetak array vektor W
print(W)