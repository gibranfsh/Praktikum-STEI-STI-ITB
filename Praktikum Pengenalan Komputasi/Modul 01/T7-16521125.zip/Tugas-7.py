#Nama : Gibran Fasha Ghazanfar
#NIM : 16521125

#TUGAS ke-7 : Program Inversi Matriks Gauss-Jordan
#SPESIFIKASI : Melakukan inversi matriks dengan menggunakan Eliminasi Gauss-Jordan
print("-----TUGAS ke-7 : Program Inversi Matriks Gauss-Jordan-----")

#KAMUS :
#n = int
#M, P = matriks int

#ALGORITMA :
M = [[0, 2, 1], [4, 0, 1], [-1, 2, 0]] #Asumsi matriks sudah diketahui
P = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
n = len(P)
def inverse(a):
    n = len(a) #Mendefinisikan rentang di mana loop akan berjalan
    #Membuat matriks augmented n X 2n
    P = [[0.0 for i in range(len(a))] for j in range(len(a))]
    for i in range(3):
        for j in range(3):
            P[j][j] = 1.0
    for i in range(len(a)):
        a[i].extend(P[i])
    #Loop utama untuk eliminasi gaussian
    for k in range(n):
        if abs(a[k][k]) < 1.0e-12:
            for i in range(k+1, n):
                if abs(a[i][k]) > abs(a[k][k]):
                    for j in range(k, 2*n):
                        a[k][j], a[i][j] = a[i][j], a[k][j] #Bertukar baris
                    break
        pivot = a[k][k] #Menentukan pivot
        if pivot == 0: #Memeriksa apakah matriks dapat diinvers
            print("Matriks ini tidak dapat diinvers")
            return
        else:
            for j in range(k, 2*n): #Indeks kolom dari baris pivot
                a[k][j] /= pivot
            for i in range(n): #Indeks baris yang dikurangi
                if i == k or a[i][k] == 0: continue
                factor = a[i][k]
                for j in range(k, 2*n): #Indeks kolom untuk pengurangan
                    a[i][j] -= factor * a[k][j]
    for i in range(len(a)): #Mencetak matriks
        for j in range(n, len(a[0])):
            print(a[i][j], end = " ")
        print()

inverse(M) #Pilih salah satu  matriks P atau M untuk diinvers "inverse(M)" atau "inverse(P)" silakan ubah!