#Nama : Gibran Fasha Ghazanfar
#NIM : 16521125

#TUGAS ke-3 : Program Menentukan Nilai Minimum Suatu Array
#SPESIFIKASI : Menentukan Nilai Minimum Suatu Array
print("-----TUGAS ke-3 : Program Menentukan Nilai Minimum Suatu Array-----")

#KAMUS :
#N, min = int
#T = array of integer

#ALGORITMA :
N = int(input("Masukan jumlah angka : ")) #Menerima jumlah angka dari pengguna
T= [0 for i in range(0, N)] #Array dengan range 0--N


for i in range(0, N):
    min = T[0]
    T[i] = int(input("Masukan nilai ke-" + str(i+1) + " : ")) #Mengisi array dari pengguna
    if T[i] < min: #Jika indeks ke-i lebih kecil daripada indeks ke-0, indeks ke-i akan menggantikan indeks ke-0
        min = T[i]
    
print("Nilai terkecil adalah : " + str(min)) #Mencetak nilai min (terkecil)


